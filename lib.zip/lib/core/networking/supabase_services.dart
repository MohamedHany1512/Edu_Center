import 'package:supabase_flutter/supabase_flutter.dart';

/// Bootstrap configuration for the Supabase backend.
///
/// Injected at compile time so credentials are not committed to source:
///
/// ```sh
/// flutter run \
///   --dart-define=SUPABASE_URL=https://xxxx.supabase.co \
///   --dart-define=SUPABASE_ANON_KEY=sb_publishable_xxx
/// ```
abstract final class SupabaseServices {
  static const String projectUrl = String.fromEnvironment('SUPABASE_URL');

  static const String publishableKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
  );

  /// Whether the required compile-time values were supplied.
  static bool get isConfigured =>
      projectUrl.isNotEmpty && publishableKey.isNotEmpty;

  /// Initialises the Supabase SDK. Must complete before the first query.
  static Future<void> init() async {
    if (!isConfigured) {
      throw StateError(
        'Supabase is not configured. Pass SUPABASE_URL and SUPABASE_ANON_KEY '
        'via --dart-define.',
      );
    }

    await Supabase.initialize(url: projectUrl, publishableKey: publishableKey);
  }
}

